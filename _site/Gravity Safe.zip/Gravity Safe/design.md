---
layout: archive
title: Design
permalink: /design/
category: "design"
tagline: "it's all about perception."
---
