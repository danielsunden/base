---
layout: archive
title: Science
permalink: /science/
tagline: "Humanity is overrated."
category: "science"
---
