---
layout: page
title: Download
permalink: /download/

tagline: "Loved it? Download Gravity"
---


<br>
<div class="download">
  <center>Just a second! <i class="fa fa-heart"></i> Star it if you loved!</center>
  <br>
<center>
  <iframe src="https://ghbtns.com/github-btn.html?user=hemangsk&repo=gravity&type=star&count=true&size=large" frameborder="0" scrolling="0" width="160px" height="30px"></iframe>

  <iframe src="https://ghbtns.com/github-btn.html?user=hemangsk&repo=gravity&type=fork&count=true&size=large" frameborder="0" scrolling="0" width="160px" height="30px"></iframe>

  <iframe src="https://ghbtns.com/github-btn.html?user=hemangsk&type=follow&count=true&size=large" frameborder="0" scrolling="0" width="200px" height="30px"></iframe>
</center>
</div>
<center>GitHub Repository
<a href=""http://github.com/heamngsk/Gravity"><p><i class="fa -fa-github"></i></p></a>
</center>
<div class="intro"><br>
  <p>
 Hello there! :) <BR><br>
 Hemang here, developer of <span class="small-site-title">Gravity</span> theme. <br>
 I'm a CS sophomore at USICT, New Delhi. <br><br>
 <a href="http://facebook.com/hemangkr"><i class="fa fa-facebook"></i></a> &nbsp; &nbsp; &nbsp;<a href="http://github.com/hemangsk"><i class="fa fa-github"></i></a>
 </p>
</div>
